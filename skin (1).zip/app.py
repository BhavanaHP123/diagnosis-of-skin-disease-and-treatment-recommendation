from flask import Flask, render_template, request, jsonify, url_for
import pandas as pd
import os

app = Flask(__name__, static_folder='static')

# Load your Excel dataset
def load_data():
    # Use relative path from the application directory
    data_path = os.path.join(os.path.dirname(__file__), 'static', 'data', 'skin_disease_dataset.xlsx')
    try:
        data = pd.read_excel(data_path, engine='openpyxl')
        return data
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/rec')
def rec():
    return render_template('rec.html')

@app.route('/brands')
def brands():
    return render_template('brands.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/get_disease_info', methods=['GET'])
def get_disease_info():
    disease_name = request.args.get('disease_name')
    data = load_data()
    
    if data is None:
        return jsonify({'message': 'Error loading disease data'}), 500
    
    # Search for the disease in the dataset
    disease_info = data[data['Disease Name'].str.contains(disease_name, case=False, na=False)]
    
    if disease_info.empty:
        return jsonify({'message': 'Disease not found'}), 404
    
    # Prepare the result
    result = {
        "message": "Disease found",
        "results": [
            {
                "disease_name": disease_info['Disease Name'].values[0],
                "image_link": disease_info['Image Link'].values[0],
                "treatment": disease_info['Treatment'].values[0],
                "symptoms": disease_info['Symptoms'].values[0],
            }
        ]
    }
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
